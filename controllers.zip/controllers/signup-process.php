<?php require 'controllers/db.php';

$message = "";

if (isset($_POST['submit-btn'])){
    $surname = $_POST['surname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $gender = $_POST['gender'];
    $std_cate = $_POST['std-cate'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpassword'];


    if ($password !== $cpassword) {
        echo '<script>alert("Password does not match")</script>';
    }else{
        $sql = 'INSERT INTO users(username, email, mobile, gender, std_cate, pass) VALUES(:username, :email, :mobile, :gender, :std_cate, :pass)';
        $stmt = $conn->prepare($sql);
        if($stmt->execute([':username' => $username, ':email' => $email, ':mobile' => $mobile, ':gender' => $gender, ':std_cate' => $std_cate, ':pass' => $password ])){
                           $message = "Data submitted Successfully";
                       }else{
                           echo '<script>alert("problem inserting data")</script>';
                           $message = "problem inserting data";
                       }

    }

        
        
    

 
}





?>
