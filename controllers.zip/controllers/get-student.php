<?php 

include 'controllers/db.php';
//get students data to display

$sql = "SELECT * FROM users where id='1'";

$stmt = $conn->execute($sql);





?>

