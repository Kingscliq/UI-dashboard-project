<?php 
    include 'db.php';

    //Get data for login authentication
    if(isset($_POST['login-btn'])){
        $sql = "SELECT * FROM users where id ='1'";

        $stmt= $conn->prepare($sql);
        $stmt->execute();
        $std = $stmt->fetch(PDO::FETCH_OBJ);

       
        
    }



?>