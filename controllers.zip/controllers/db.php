<?php

    $dsn =  'mysql:host=localhost;dbname=std_reg_db';
    $user = 'root';
    $pass = '';
    $option = [];
try{
    $conn = new PDO($dsn, $user, $pass, $option);

}catch(PDOException $e){
    echo 'Error connecting to database..';
}
    
    